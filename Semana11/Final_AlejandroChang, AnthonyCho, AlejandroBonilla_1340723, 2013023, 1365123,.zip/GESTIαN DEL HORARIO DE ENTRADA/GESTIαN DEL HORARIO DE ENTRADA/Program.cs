﻿class Program
{


    static void Main(string[] args)
    {
        string[] nombres = new string[3];
        string[] carnes = new string[3];
        string[] carreras = new string[3];

        // Datos de créditos
        string nombreProyecto = "Gestionar el horario de entrada del personal de limpieza de la jornada matutina de la Universidad Rafael Landívar";
        string fechaCreacion = "19 de octubre del 2023";
        int horasInvertidas = 8;

        // Menú principal
        while (true)
        {
            Console.Clear();
            Console.WriteLine("Gestión del Horario de Entrada - Universidad Rafael Landívar");
            Console.WriteLine("1. Proceso principal (servicio)");
            Console.WriteLine("2. Manual de usuario");
            Console.WriteLine("3. Créditos");
            Console.WriteLine("4. Salir");

            Console.Write("Selecciona una opción: ");
            int opcion;
            if (!int.TryParse(Console.ReadLine(), out opcion))
            {
                Console.WriteLine("Opción no válida. Introduce un número del 1 al 4.");
                continue;
            }

            switch (opcion)
            {
                case 1:
                    Console.Clear();
                    Console.WriteLine("Proceso principal (servicio)");
                    Console.WriteLine("1. Trabajadores que llegaron tarde");
                    Console.WriteLine("2. Trabajadores que llegaron temprano");
                    Console.WriteLine("3. Trabajadores que llegaron a tiempo");
                    Console.Write("Selecciona una opción: ");
                    int subOpcion;
                    if (!int.TryParse(Console.ReadLine(), out subOpcion) || subOpcion < 1 || subOpcion > 3)
                    {
                        Console.WriteLine("Opción no válida. Introduce un número del 1 al 3.");
                        continue;
                    }
                    switch (subOpcion)
                    {
                        case 1:
                            Console.WriteLine("El trabajador llegó tarde.");
                            break;
                        case 2:
                            Console.WriteLine("El trabajador llegó temprano.");
                            break;
                        case 3:
                            Console.WriteLine("El trabajador llegó a tiempo.");
                            break;
                    }
                    Console.Write("Presiona cualquier tecla para continuar...");
                    Console.ReadKey();
                    break;

                case 2:
                    Console.Clear();
                    Console.WriteLine("Manual de usuario");
                    Console.WriteLine("1. La primera opción es con relación a los trabajadores que llegaron tarde a su labor.");
                    Console.WriteLine("2. La segunda opción es para los trabajadores que llegaron temprano.");
                    Console.WriteLine("3. La tercera y última es para los que llegaron a tiempo en el horario establecido.");
                    Console.Write("Presiona cualquier tecla para continuar...");
                    Console.ReadKey();
                    break;

                case 3:
                    Console.Clear();
                    Console.WriteLine("Créditos");
                    Console.WriteLine("Nombre del proyecto: " + nombreProyecto);
                    Console.WriteLine("Fecha de creación: " + fechaCreacion);
                    Console.WriteLine("Estimado de horas invertidas en la creación del programa: " + horasInvertidas + " horas");
                    Console.WriteLine("Datos de los integrantes:");

                    for (int i = 0; i < 3; i++)
                    {
                        Console.WriteLine("Integrante " + (i + 1) + ":");
                        Console.Write("Nombre y Apellido: ");
                        nombres[i] = Console.ReadLine();
                        Console.Write("Carné: ");
                        carnes[i] = Console.ReadLine();
                        Console.Write("Carrera: ");
                        carreras[i] = Console.ReadLine();
                    }

                    Console.WriteLine("Datos de los integrantes:");
                    for (int i = 0; i < 3; i++)
                    {
                        Console.WriteLine("Integrante " + (i + 1) + ":");
                        Console.WriteLine("Nombre y Apellido: " + nombres[i]);
                        Console.WriteLine("Carné: " + carnes[i]);
                        Console.WriteLine("Carrera: " + carreras[i]);
                    }
                    Console.Write("Presiona cualquier tecla para continuar...");
                    Console.ReadKey();
                    break;

                case 4:
                    Console.WriteLine("Saliendo del programa.");
                    return;

                default:
                    Console.WriteLine("Opción no válida. Introduce un número del 1 al 4.");
                    break;
            }
        }
    }
}


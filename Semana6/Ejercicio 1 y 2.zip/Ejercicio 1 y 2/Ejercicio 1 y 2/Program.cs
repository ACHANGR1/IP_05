﻿using System;

    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Ejercicios 1: operaciones aritméticas");

            Console.Write("Ingrese el primer número: ");
            double numero1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("Ingrese el segundo número: ");
            double numero2 = Convert.ToDouble(Console.ReadLine());

            double suma = numero1 + numero2;
            double resta = numero1 - numero2;
            double multiplicacion = numero1 * numero2;
            double division = numero1 / numero2;
            int div = (int)numero1 / (int)numero2;
            int mod = (int)numero1 % (int)numero2;

            Console.WriteLine("EL resultado de la suma es: " + suma);
            Console.WriteLine("El resultado de la  resta es: " + resta);
            Console.WriteLine("El resultado de la multiplicación es: " + multiplicacion);
            Console.WriteLine("El resultado de la divisón es: " + division);
            Console.WriteLine("El resultado de la div es: " + div);
            Console.WriteLine("El resultado del mod es: " + mod);

            Console.WriteLine("Ejercicio 2: Operaciones booleanas ");

            bool esmayorque = numero1 > numero2;
            bool esmenorque = numero1 < numero2;
            bool esigual = numero1 == numero2;

            Console.WriteLine(numero1 + " > " + numero2 + " = " + esmayorque);
            Console.WriteLine(numero1 + " < " + numero2 + " = " + esmenorque);
            Console.WriteLine(numero1 + " == " + numero2 + " = " + esigual);

        Console.ReadKey();
        }
    }

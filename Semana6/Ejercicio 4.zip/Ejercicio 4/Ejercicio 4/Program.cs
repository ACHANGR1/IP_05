﻿using System;
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ejercicio 4: Expresión cuadrática");

        Console.Write("Ingrese el valor de a: ");
        double a = double.Parse(Console.ReadLine());

        Console.Write("Ingrese el valor de b: ");
        double b = double.Parse(Console.ReadLine());

        Console.Write("Ingrese el valor de c: ");
        double c = double.Parse(Console.ReadLine());

        double expresioncuadratica = b * b - 4 * a * c;

        if (expresioncuadratica < 0)
        {
            Console.WriteLine("No existen soluciones");
        }
        else
        {

            double y1 = (-b + Math.Sqrt(expresioncuadratica)) / (2 * a);
            double y2 = (-b - Math.Sqrt(expresioncuadratica)) / (2 * a);

            Console.WriteLine("La solución 1 es = " + y1);
            Console.WriteLine("La solución 2 es = " + y2);
        }

        Console.ReadLine();
    }
}



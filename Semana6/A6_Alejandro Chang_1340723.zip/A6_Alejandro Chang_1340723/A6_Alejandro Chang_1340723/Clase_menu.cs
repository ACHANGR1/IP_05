﻿using System.Linq.Expressions;

class Clase_menu
{
    static void Main(string[] args)
    {
        Console.WriteLine("Programa mi control de marcaje ");
        Console.WriteLine();
        Console.WriteLine("Seleccionar opción ");
        Console.WriteLine();
        Console.WriteLine(" 1. Trabajadores que entraron tarde ");
        Console.WriteLine(" 2. Trabajadores que llegaron temprano ");
        Console.WriteLine(" 3. Trabajadores que llegaron a tiempo ");
        string opcion = Console.ReadLine();
        switch (opcion)
        {
            case "1":
                Console.WriteLine("Trabajadores que entraron tarde ");
                break;
            case "2":
                Console.WriteLine("Trabajadores que llegaron temprano ");
                break;
            case "3":
                Console.WriteLine("Trabajadores que llegaron a tiempo ");
                break;
       
            default:
                Console.WriteLine("Selecciono una opcion inavlida ");
                break;
                // termina instruccion switch
                Console.WriteLine("Seleccionar opcion " + opcion);
                Console.ReadKey();



        }
}
}




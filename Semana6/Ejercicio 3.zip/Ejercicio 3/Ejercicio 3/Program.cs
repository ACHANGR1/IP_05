﻿using System;
class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ejercicio 3: Jerarquía de operaciones ");

        double a = 0.0;
        double b = 0.0;
        double c = 0.0;

        Console.WriteLine("Ingrese número 1 ");
        a = double.Parse(Console.ReadLine());
        Console.WriteLine("Ingrese número 2 ");
        b = double.Parse(Console.ReadLine());
        Console.WriteLine("Ingrese número 3 ");
        c = double.Parse(Console.ReadLine());

        double operacion1 = 0.0;
        double operacion2 = 0.0;
        double operacion3 = 0.0;
        double operacion4 = 0.0;

        operacion1 = a * b + c;
        operacion2 = a * (b + c);
        operacion3 = a / (b * c);
        operacion4 = (3 * a + 2 * b) / (Math.Pow(c, 2));

        Console.WriteLine("La operación 1 es: " + operacion1);
        Console.WriteLine("La operación 2 es: " + operacion2);
        Console.WriteLine("La operación 3 es: " + operacion3);
        Console.WriteLine("La operación 4 es: " + operacion4);

            Console.ReadKey();

    }
}



﻿using System;

class Program
{
    static void Main()
    {
        int[] numeros = new int[10];

        for (int i = 0; i < 10; i++)
        {
            Console.Write($"Ingrese el número en la posición {i}: ");
            numeros[i] = Convert.ToInt32(Console.ReadLine());
        }

        int minimo = numeros[0];
        int maximo = numeros[0];

        int sumaTotal = 0;

        Console.WriteLine("Números ingresados ordenados por posición iniciando de 0 hasta la última posición:");
        for (int i = 0; i < 10; i++)
        {
            Console.Write($"{numeros[i]} ");
            sumaTotal += numeros[i];

            if (numeros[i] < minimo)
            {
                minimo = numeros[i];
            }

            if (numeros[i] > maximo)
            {
                maximo = numeros[i];
            }
        }

        Console.WriteLine("\nNúmeros ingresados ordenados por posición iniciando de la última posición y terminando en la primera posición:");
        for (int i = 9; i >= 0; i--)
        {
            Console.Write($"{numeros[i]} ");
        }

        double promedio = (double)sumaTotal / 10;

        int sumaPares = 0;
        int sumaImpares = 0;

        for (int i = 0; i < 10; i++)
        {
            if (i % 2 == 0)
            {
                sumaPares += numeros[i];
            }
            else
            {
                sumaImpares += numeros[i];
            }
        }

        Console.WriteLine($"\n\na. Número más pequeño: {minimo}");
        Console.WriteLine($"b. Número más grande: {maximo}");
        Console.WriteLine($"c. Suma total: {sumaTotal}");
        Console.WriteLine($"d. Promedio: {promedio}");
        Console.WriteLine($"e. Suma de posiciones pares: {sumaPares}");
        Console.WriteLine($"f. Suma de posiciones impares: {sumaImpares}");
    }
}
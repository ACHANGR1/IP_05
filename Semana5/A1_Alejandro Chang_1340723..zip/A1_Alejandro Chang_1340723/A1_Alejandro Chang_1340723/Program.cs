﻿class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Mi segundo programa ");
        string sNombre, sEdad, sCarrera, sCarne;

        //Ingreso de nombre
        Console.WriteLine("Ingrese nombre ");
        sNombre = Console.ReadLine();

        //Ingreso de edad
        Console.WriteLine("Ingrese edad ");
        sEdad = Console.ReadLine();

        //Ingreso de carrera
        Console.WriteLine("Ingrese carrera ");
        sCarrera = Console.ReadLine();

        //Ingreso de carne
        Console.WriteLine("Ingrese carne ");
        sCarne = Console.ReadLine();

        Console.WriteLine();
        Console.WriteLine("Mi segundo programa ");
        Console.WriteLine("Nombre: " + sNombre);
        Console.WriteLine("Edad: " + sEdad);
        Console.WriteLine("Carrera: " + sCarrera);
        Console.WriteLine("Carne: " + sCarne);

        Console.Write("soy " + sNombre + " tengo " + sEdad + " años y estudio la carrera de " + sCarrera);
        Console.Write(", mi numero de carne es " + sCarne);
        Console.ReadKey();
    }
}


﻿using System;

class Program
{
    static void Main()
    {
        try
        {
            Console.Write("Ingrese el monto de la compra (GTQ): ");
            string montoStr = Console.ReadLine();

            decimal monto = decimal.Parse(montoStr);

            decimal descuentoBase = 0;

            if (monto < 400)
                descuentoBase = 0;
            else if (monto <= 1000)
                descuentoBase = 0.07m;
            else if (monto <= 5000)
                descuentoBase = 0.10m;
            else if (monto <= 15000)
                descuentoBase = 0.15m;
            else
                descuentoBase = 0.25m;

            Console.Write("¿Usted tiene algún código de descuento? (si o no): ");
            string tieneDescuentoStr = Console.ReadLine();

            decimal descuentoAdicional = 0;

            if (tieneDescuentoStr.ToUpper() == "S")
                descuentoAdicional = 0.05m;

            decimal montoFinal = monto - (monto * (descuentoBase + descuentoAdicional));

            Console.WriteLine($"Monto a pagar después de descuentos: Q{montoFinal:F2}");
        }
        catch (FormatException)
        {
            Console.WriteLine("Error: Ingrese un monto válido.");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"Error inesperado: {ex.Message}");
        }
    }
}
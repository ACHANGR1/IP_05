﻿using System;
using System.ComponentModel.Design;

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ejercicio 1 ");
        int numero1;

        Console.WriteLine("Ingrese el primer número ");
        numero1 = Int32.Parse(Console.ReadLine());

        if (numero1 > 0)
        {
            Console.WriteLine("El número es positivo ");
        }
        else if (numero1 < 0)
        {
            Console.WriteLine("El número es negativo ");
        }
        else
        {
            Console.WriteLine("El número es 0 ");
        }

        Console.WriteLine("Ejercicio 2 ");
        int dia;

        Console.WriteLine("Ingrese el número de día ");
        dia = Int32.Parse(Console.ReadLine());

        if (dia == 1)
        {
            Console.WriteLine("DIA: Lunes");
        }
        else if (dia == 2)
        {
            Console.WriteLine("DIA: Martes");
        }
        else if (dia == 3)
        {
            Console.WriteLine("DIA: Miércoles");
        }
        else if (dia == 4)
        {
            Console.WriteLine("DIA: Jueves");
        }
        else if (dia == 5)
        {
            Console.WriteLine("DIA: Viernes");
        }
        else if (dia == 6)
        {
            Console.WriteLine("DIA: Sábado");
        }
        else if (dia == 7)
        {
            Console.WriteLine("DIA: Domingo");
        }
        else
        {
            Console.WriteLine("Error: El número a ingresar debe estar contenido entre 1 y 7");
        }
        Console.ReadKey();
    }
}
